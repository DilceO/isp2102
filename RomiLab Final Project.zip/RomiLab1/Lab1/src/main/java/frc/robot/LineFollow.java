package frc.robot;

import edu.wpi.first.wpilibj.Timer;
import frc.navigation.Odometry;

public class LineFollow {

    LightSensor lightSensor = new LightSensor();
    RomiDrivetrain drivetrain = new RomiDrivetrain();
    Odometry odometry;
    public int turnNum = 0;
    public double baseSpeed = 0.35;
    public double turnSpeed = 0.3;
    public double kp = 0.1;

    public LineFollow(Odometry o) {
        odometry = o;
    }

    public void lineFollower() {
        while (!lightSensor.onIntersection()) {
            drivetrain.arcadeDrive(baseSpeed, lightSensor.getError() * kp);
        }
    }

    
    /** 
     * Drives a given number of intersections.
     * @param intersectionNumber
     */
    public void lineIntersection(int intersectionNumber) {
        for (int i = 0; i < intersectionNumber; i++) {
            lineFollower();
            odometry.wentIntersection();
            while (lightSensor.onIntersection()) {
                drivetrain.arcadeDrive(baseSpeed, 0);
            }
        }
    }

    
    /** 
     * Turns right until robot is back on the line.
     * @param turnNum
     */
    public void lineTurnRight(int turnNum) {
        drivetrain.arcadeDrive(baseSpeed, 0);
        Timer.delay(0.7);
        for (int i = 0; i < turnNum; i++) {
            drivetrain.arcadeDrive(0, turnSpeed);
            Timer.delay(1);
            while (!lightSensor.inWhite()) {
                drivetrain.arcadeDrive(0, turnSpeed);
            }
            drivetrain.arcadeDrive(0, turnSpeed);
            Timer.delay(1);
            while (lightSensor.inWhite()) {
                drivetrain.arcadeDrive(0, turnSpeed);
            }
            drivetrain.arcadeDrive(0, turnSpeed);
            Timer.delay(0.5);
            drivetrain.arcadeDrive(0, 0);
            odometry.turnedRight();
        }
    }

    
    /** 
     * Turns left until robot is back on the line.
     * @param turnNum
     */
    public void lineTurnLeft(int turnNum) {
        drivetrain.arcadeDrive(baseSpeed, 0);
        Timer.delay(0.7);
        for (int i = 0; i < turnNum; i++) {
            drivetrain.arcadeDrive(0, -1 * turnSpeed);
            Timer.delay(0.5);
            while (!lightSensor.inWhite()) {
                drivetrain.arcadeDrive(0, -1 * turnSpeed);
            }
            drivetrain.arcadeDrive(0, -1 * turnSpeed);
            Timer.delay(0.5);
            while (lightSensor.inWhite()) {
                drivetrain.arcadeDrive(0, -1 * turnSpeed);
            }
            drivetrain.arcadeDrive(0, -1 * turnSpeed);
            Timer.delay(0.5);
            drivetrain.arcadeDrive(0, 0);
            odometry.turnedLeft();
        }
    }

    public void circleRun() {
        for (int i = 0; i < 2; i++) {
            lineIntersection(2);
            lineTurnLeft(1);
        }
    }

    public void intersectionPause(){
        drivetrain.arcadeDrive(0, 0);
        Timer.delay(10);
    }
}

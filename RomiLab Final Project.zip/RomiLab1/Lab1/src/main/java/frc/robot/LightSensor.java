package frc.robot;

import edu.wpi.first.wpilibj.AnalogInput;

public class LightSensor {

    private final AnalogInput leftSensor;
    private final AnalogInput rightSensor;

    public LightSensor(){
        leftSensor = new AnalogInput(0);
        rightSensor = new AnalogInput(1);
    }

/** 
 * Calculates the difference between the values the light sensors are reading.
 * @return double
 */
public double getError(){
    return leftSensor.getAverageVoltage() - rightSensor.getAverageVoltage();
}



/** 
 * Tells when robot is on an intersection.
 * @return boolean
 */
public boolean onIntersection(){
    if(leftSensor.getAverageVoltage() > 1.8 && rightSensor.getAverageVoltage() > 1.8){
        return true;
    }
        return false;
    }

    
    /** 
     * Tells when robot is not on the line.
     * @return boolean
     */
    public boolean inWhite(){
        while(leftSensor.getAverageVoltage() < 0.5 && rightSensor.getAverageVoltage() < 0.5){
            return true;
        }
        return false;
    }
}

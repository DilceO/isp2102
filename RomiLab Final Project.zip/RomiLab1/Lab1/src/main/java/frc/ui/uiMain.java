package frc.ui;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import frc.navigation.Grid;

public class uiMain {

   
   /** 
    * Creates the grid.
    * @param grid
    */
   public static void createAndShowGui(Grid grid) {
      int cellWidth = 20;
      UiGrid mainPanel = new UiGrid(grid, cellWidth);

      JFrame frame = new JFrame("Color Grid Example");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add(mainPanel);
      frame.pack();
      frame.setLocationByPlatform(true);
      frame.setVisible(true);
   }

   
   /** 
    * @param args
    */
   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            // createAndShowGui();
         }
      });
   }
}

package frc.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.plaf.PanelUI;

import frc.navigation.Grid;
import frc.navigation.GridNavigator;

@SuppressWarnings("serial")
public class UiGrid extends JPanel {
   private MyColor[][] myColors;
   private JLabel[][] myLabels;
   private Grid grid;
   private GridNavigator gridNav;
   private JLabel myLabel;

   public UiGrid(Grid grid, int cellWidth) {
      this.gridNav = new GridNavigator(grid);
      this.grid = grid;
      int rows = grid.rowCount();
      int cols = grid.collumnCount();
      myColors = new MyColor[rows][cols];
      myLabels = new JLabel[rows][cols];
      MyMouseListener myListener = new MyMouseListener(this);
      Dimension labelPrefSize = new Dimension(cellWidth, cellWidth);
      GridLayout gridLay = new GridLayout(rows, cols);
      setLayout(gridLay);
      System.out.println("Rows: [" + rows + "Cols: [" + cols);
      for (int row = 0; row < myLabels.length; row++) {
         for (int col = 0; col < myLabels[row].length; col++) {
            System.out.println("row num: [" + row + "col num: [" + col);
            JLabel myLabel = new JLabel();
            myLabel.setOpaque(true);
            MyColor myColor = MyColor.WHITE;
            myColors[row][col] = myColor;
            myLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            myLabel.setBackground(myColor.getColor());
            myLabel.addMouseListener(myListener);
            myLabel.setPreferredSize(labelPrefSize);
            add(myLabel);
            myLabels[row][col] = myLabel;
         }
      }
   }

   
   /** 
    * Colors being used.
    * @return MyColor[][]
    */
   public MyColor[][] getMyColors() {
      return myColors;
   }

   
   /** 
    * Navigates the robot to a clicked square on the grid.
    * @param label
    */
   public void labelPressed(JLabel label) {

      

      for (int row = 0; row < myLabels.length; row++) {
         for (int col = 0; col < myLabels[row].length; col++) {
            if (label == myLabels[row][col]) {
               gridNav.navigate(row, col);
               System.out.println("GUI Curr Pos [" + row + col + "]");
               MyColor myColor = myColors[row][col].next();
               myColors[row][col] = myColor;
               myLabels[row][col].setBackground(myColor.getColor());
            }
         }
      }
   }
}

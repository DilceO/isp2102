package frc.ui;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class MyMouseListener extends MouseAdapter {
   private UiGrid colorGrid;

   public MyMouseListener(UiGrid colorGrid) {
      this.colorGrid = colorGrid;
   }

   
   /** 
    * Right click on grid to highlight a square and set it as a destination.
    * @param e
    */
   @Override
   public void mousePressed(MouseEvent e) {
      if (e.getButton() == MouseEvent.BUTTON1) {
         colorGrid.labelPressed((JLabel)e.getSource());
      } else if (e.getButton() == MouseEvent.BUTTON3) {
         MyColor[][] myColors = colorGrid.getMyColors();
         for (int row = 0; row < myColors.length; row++) {
            for (int col = 0; col < myColors[row].length; col++) {
               System.out.print(myColors[row][col] + " ");
            }
            System.out.println();
         }
         System.out.println();
      }
   }
}

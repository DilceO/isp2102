package frc.navigation;

import java.util.ArrayList;
import java.util.HashMap;
import java.text.MessageFormat;
import java.util.*;

public class Node {
    private int x;
    private int y;
    private Grid parentGrid;
    private ArrayList<Node> neighborList;

    private LinkedList<Node> shortestPath = new LinkedList<>();
    private Integer distance = Integer.MAX_VALUE;
    Map<Node, Integer> adjacentNodes = new HashMap<>();
    private int cost;


    public Node(Grid parentGrid, int x, int y){  //thing I'm following wants just name as string for node
        this.parentGrid = parentGrid;
        this.x = x;
        this.y = y;
    }

    
    /** 
     * Finds the x coordinate of a node.
     * @return int
     */
    public int getX(){
        return x;
    }

    
    /** 
     * Finds the y coordinate of a node.
     * @return int
     */
    public int getY(){
        return y;
    }

    
    /** 
     * Makes a list of the nodes neighboring a node.
     * @return ArrayList<Node>
     */
    public ArrayList<Node> neighboringNodes(){
        neighborList = new ArrayList<Node>();
        if(parentGrid.inBounds(this.getX(), this.getY())){
            if(this.getX() > 0 && this.getX() < this.parentGrid.rowCount() - 1){
                neighborList.add(this.parentGrid.getNode(x + 1, y));
                neighborList.add(this.parentGrid.getNode(x - 1, y));
            }
            if(this.getY() > 0 && this.getY() < this.parentGrid.collumnCount() - 1){
                neighborList.add(this.parentGrid.getNode(x, y + 1));
                neighborList.add(this.parentGrid.getNode(x, y - 1));
            }
            if(this.getX() == 0){
                neighborList.add(this.parentGrid.getNode(x + 1, y));
            }
            if(this.getX() == this.parentGrid.rowCount() - 1){
                neighborList.add(this.parentGrid.getNode(x - 1, y));
            }
            if(this.getY() == 0){
                neighborList.add(this.parentGrid.getNode(x, y + 1));
            }
            if(this.getY() == this.parentGrid.collumnCount() - 1){
                neighborList.add(this.parentGrid.getNode(x, y - 1));
            }
        }
        // System.out.println(neighborList);
        return neighborList;
    }

    
    /** 
     * 
     * @param destination
     * @param distance
     */
    public void addDestination(Node destination, int distance){
        adjacentNodes.put(destination, distance);
    }

    
    /** 
     * @param dist
     */
    public void setDistance(int dist){
        this.distance = dist;
    }

    
    /** 
     * @return int
     */
    public int getDistance(){
        return distance;
    }

    
    /** 
     * @return List<Node>
     */
    public List<Node> getShortestPath(){
        return this.shortestPath;
    }

    
    /** 
     * @param shortestPath
     */
    public void setShortestPath(LinkedList<Node> shortestPath){
        this.shortestPath = shortestPath;
    }

    
    /** 
     * @return Map<Node, Integer>
     */
    public Map<Node, Integer> getAdjacentNodes(){
        return adjacentNodes;
    }

    
    /** 
     * @param adjacentNodes
     */
    public void setAdjacentNodes(Map<Node, Integer> adjacentNodes){
        this.adjacentNodes = adjacentNodes;
    }

    
    /** 
     * @return String
     */
    public String nodeToString(){
        String message = MessageFormat.format("x = [{0}], y = [{1}]", x, y);
        return message;
    }

    
    /** 
     * @param cost
     */
    public void setCost(int cost){
        this.cost = cost;
    }

    
    /** 
     * @return int
     */
    public int getCost(){
        return cost;
    }
}

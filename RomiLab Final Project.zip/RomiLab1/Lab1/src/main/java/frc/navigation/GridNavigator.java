package frc.navigation;

import java.util.*;

import frc.robot.LineFollow;

public class GridNavigator {
    Odometry odometry = new Odometry();
    LineFollow lineFollow = new LineFollow(odometry);
    
    Grid grid;
    public int posX;
    public int posY;
    public int desDir;
    public int turnNum;
    public Dijkstra dijkstra;

    public GridNavigator(Grid g) {
        grid = g;
        dijkstra = new Dijkstra();
    }

    
    /** 
     * Finds how much the robot needs to turn to get to a desired x coordinate based off of the direction it is currently facing.
     * @param posX
     */
    public void findDirX(int posX) {
        if (posX > odometry.currX) {
            desDir = 0;
        }
        if (posX < odometry.currX) {
            desDir = 2;
        }
    }

    
    /** 
     * Finds how much the robot needs to turn to get to a desired y coordinate based off of the direction it is currently facing.
     * @param posY
     */
    public void findDirY(int posY) {
        if (posY > odometry.currY) {
            desDir = 3;
        }
        if (posY < odometry.currY) {
            desDir = 1;
        }
    }

    
    /** 
     * Turns the robot the least amount of times to face a desired direction.
     * @param desDir
     */
    public void turnDir(int desDir) {
        while (desDir != odometry.currDir) {
            // cases for robot inside grid
            if (!grid.onBounds(odometry.currX, odometry.currY)) {
                if (desDir == 3 && odometry.currDir == 0) {
                    lineFollow.lineTurnLeft(1);
                }
                if (desDir == 0 && odometry.currDir == 3) {
                    lineFollow.lineTurnRight(1);
                }
                if (desDir > odometry.currDir) {
                    turnNum = desDir - odometry.currDir;
                    lineFollow.lineTurnRight(turnNum);
                }
                if (desDir < odometry.currDir) {
                    turnNum = odometry.currDir - desDir;
                    lineFollow.lineTurnLeft(turnNum);
                }
            }
            // cases for if robot is on edge of grid (so it turns over lines)
            // row cases
            if(grid.onBounds(odometry.currX, odometry.currY)){
            if (odometry.currX == 0) {
                if (odometry.currDir == 3 && desDir == 0) {
                    turnNum = 1;
                    lineFollow.lineTurnRight(turnNum);
                }
                if (odometry.currDir == 1 && desDir == 0) {
                    turnNum = 1;
                    lineFollow.lineTurnLeft(turnNum);
                }
                if(odometry.currDir == 0 && desDir == 3){
                    turnNum = 1;
                    lineFollow.lineTurnLeft(turnNum);
                }
                if (desDir != odometry.currDir) {
                    turnNum = Math.abs(desDir - odometry.currDir);
                    lineFollow.lineTurnLeft(turnNum);
                }
            }
            if (odometry.currX == grid.rowCount()) {
                if (odometry.currDir == 1 && desDir == 2) {
                    turnNum = 1;
                    lineFollow.lineTurnRight(turnNum);
                }
                if (odometry.currDir == 3 && desDir == 2) {
                    turnNum = 1;
                    lineFollow.lineTurnLeft(turnNum);
                }
                if (desDir != odometry.currDir) {
                    turnNum = Math.abs(desDir - odometry.currDir);
                    lineFollow.lineTurnLeft(turnNum);
                }
            }
            // collumn cases
            if (odometry.currY == 0) {
                if (odometry.currDir == 2 && desDir == 3) {
                    turnNum = 1;
                    lineFollow.lineTurnRight(turnNum);
                }
                if (odometry.currDir == 0 && desDir == 3) {
                    turnNum = 1;
                    lineFollow.lineTurnLeft(turnNum);
                }
                if (desDir != odometry.currDir) {
                    turnNum = Math.abs(desDir - odometry.currDir);
                    lineFollow.lineTurnLeft(turnNum);
                }
            }
            if (odometry.currY == grid.collumnCount()) {
                if (odometry.currDir == 0 && desDir == 1) {
                    turnNum = 1;
                    lineFollow.lineTurnRight(turnNum);
                }
                if (odometry.currDir == 2 && desDir == 1) {
                    turnNum = 1;
                    lineFollow.lineTurnLeft(turnNum);
                }
                if (desDir != odometry.currDir) {
                    turnNum = Math.abs(desDir - odometry.currDir);
                    lineFollow.lineTurnLeft(turnNum);
                }
            }
        }}
    }

    
    /** 
     * Navigates the robot to a desired position Manhattan style.
     * @param posX
     * @param posY
     */
    public void navigateManhattan(int posX, int posY) {
        while (posX != odometry.currX) {
            findDirX(posX);
            turnDir(desDir);
            for (int i = 0; i < Math.abs(posX - odometry.currX); i++) {
                lineFollow.lineIntersection(1);
            }
        }
        while (posY != odometry.currY) {
            findDirY(posY);
            turnDir(desDir);
            for (int i = 0; i <= Math.abs(posY - odometry.currY); i++) {
                lineFollow.lineIntersection(1);
            }
           // lineFollow.intersectionPause();
        }
    }

    
    /** 
     * Navigates the robot to a desired position using Dijkstra's algorithm.
     * @param source
     * @param goal
     */
    public void navigateDijkstra(Node source, Node goal) {
        List<Node> f = dijkstra.shortestPath(grid, source, goal);
        System.out.println("List size: [" + f.size() + "]");
        System.out.println("Shortese path: [" + dijkstra.shortestPathList(f) + "]");
        for (Node path : dijkstra.shortestPath(grid, source, goal)) {
            System.out.println("Curr Dir: ["+ odometry.currDir + "]");
        navigateManhattan(path.getX(), path.getY());
        System.out.println("current pos: [" + path.nodeToString() + "]");
    }
    lineFollow.intersectionPause();
}
    /** 
     * Navigates the robot using Dijkstra's algorithm based off of the UI.
     * @param x
     * @param y
     */

    public void navigate(int x, int y) {
        Node source = grid.getNode(odometry.currX, odometry.currY);
        Node goal = grid.getNode(x, y);

        String message = String.format("Starting navigation.  From: [%s], To: [%s]", source.nodeToString(), goal.nodeToString());
        System.out.println(message);

        navigateDijkstra(source, goal);
    }
}
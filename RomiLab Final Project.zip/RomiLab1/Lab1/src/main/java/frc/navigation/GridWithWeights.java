package frc.navigation;

import java.util.Hashtable;

public class GridWithWeights extends Grid {
    Hashtable<Node, Integer> weights;

    public GridWithWeights(int rows, int collumns) {
        super(rows, collumns);
        this.weights = new Hashtable<Node, Integer>();
    }
    
    
    /** 
     * I don't think I use this
     * @param startNode
     * @param endNode
     * @return int
     */
    public int getCost(Node startNode, Node endNode){
        if(!weights.containsKey(endNode)){
            this.weights.put(endNode, 1);
        }
        return this.weights.get(endNode);
    }
}

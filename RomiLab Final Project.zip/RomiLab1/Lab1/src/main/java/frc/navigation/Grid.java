package frc.navigation;

import java.util.*;

public class Grid {
    private int rows;
    private int collumns;
    private Set<Node> nodes = new HashSet<>();

    

    public Grid(int rows, int collumns){
         nodes = new HashSet<Node>();
         for(int x = 0; x < rows; x++){
             for(int y = 0; y < collumns; y++){
                 //nodes[x][y] = new Node(x,y);
                nodes.add(new Node(this, x, y));
             }
         }
        this.rows = rows;
        this.collumns = collumns;
    }

    
    /** 
     * Gets a node from an x and y coordinate
     * @param x
     * @param y
     * @return Node
     */
    public Node getNode(int x, int y) {
        if (inBounds(x, y)) {
            return new Node(this, x, y);
        } else {
            System.out.println("get node x: [" + x +"]");
            System.out.println("get node y: [" + y +"]");
            return null;
        }
    }

    
    /** 
     * Gets nodes from a hashset of nodes.
     * @return Set<Node>
     */
    public Set<Node> getNodes() {
        return nodes;
    }

    
    /** 
     * Checks if coordinates are in the bounds of the grid.
     * @param x
     * @param y
     * @return boolean
     */
    public boolean inBounds(int x, int y){
        if((x > 0 || x < rows-1) && (y > 0 || y < collumns - 1)){
            return true;
        }
        return false;
    }

    
    /** 
     * Checks if coordinates are on the outside bounds of the grid.
     * @param x
     * @param y
     * @return boolean
     */
    public boolean onBounds(int x, int y){
        if(x == 0 || x == rows){
            return true;
        }
        if(y == 0 || y == collumns){
            return true;
        }
        return false;
    }

    
    /** 
     * Amount of rows in the grid.
     * @return int
     */
    public int rowCount(){
        return rows;
    }

    
    /** 
     * Amount of collumns in the grid.
     * @return int
     */
    public int collumnCount(){
        return collumns;
    }

    
    /** 
     * Adds a node to the hashset of nodes.
     * @param nodeA
     */
    //public int cost()

    public void addNode(Node nodeA){
        nodes.add(nodeA);
    }
    
}

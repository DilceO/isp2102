package frc.navigation;

import java.util.*;


public class Dijkstra {
    Grid grid;
    Node source;
    Node goal;

    
    /** 
     * Finds the shortest path between a start and end node.
     * @param grid
     * @param source
     * @param goal
     * @return List<Node>
     */
    public List<Node> shortestPath(Grid grid, Node source, Node goal){
        System.out.println(goal.nodeToString());
        System.out.println(source.nodeToString());
        source.setDistance(0); 

        HashSet<Node> settled = new HashSet<>();
        HashSet<Node> unsettled = new HashSet<>();

        unsettled.add(source);
        
        //System.out.println("source: [" + source.nodeToString() + "]");
        //System.out.println("unsettled empty?: [" + unsettled.isEmpty() + "]");

        while(!unsettled.isEmpty()){
           // System.out.println("unsettled size: [" + unsettled.size() + "]"); //should be 1 the first time
            Node current = getLowestDist(unsettled);
            unsettled.remove(current);
            settled.add(current);
           // System.out.println("current path: [" + current.getShortestPath() + "]");
            if(current.getX() == goal.getX() && current.getY() == goal.getY()){
                //System.out.println("found goal");
               // System.out.println("shortest path: [" + grid.getNode(goal.getX(), goal.getY()).getShortestPath() + "]");
               // System.out.println("shortest path size: [" + goal.getShortestPath().size() + "]");
                List<Node> realPath = current.getShortestPath();
                realPath.remove(0);
                realPath.add(goal);
                return realPath;
            }
          //  System.out.println("Current node: [" + current.nodeToString() + "]");
            for(Node neighbor : current.neighboringNodes()) {
              //  System.out.println("unsettled?: [" + unsettled.contains(neighbor) + "]");
                if(!inList(settled, neighbor) && !inList(unsettled, neighbor)){
                  //  System.out.println("current neighbor: [" + neighbor.nodeToString() + "]");
                    neighbor = calculateMinDist(neighbor, 1, current); //1 is edgeweight
                    neighbor.getShortestPath();
                  //  System.out.println("neighbor shortest path: [" + neighbor.getShortestPath() + "]");
                   // System.out.println("current neighbor: [" + neighbor.nodeToString() + "]");
                    unsettled.add(neighbor);
                  //  System.out.println("unsettled size2: [" + unsettled.size() + "]");
                }
            }
          //  System.out.println("settled size: [" + settled.size() + "]");
        }
        return null;
    }

    
    /** 
     * List of nodes into a string for the shortest path.
     * @param shortestPath
     * @return String
     */
    public String shortestPathList(List<Node> shortestPath){
        String s1 = "";
       for(Node node : shortestPath){
           String n = node.nodeToString();
           s1 = s1.concat(n);
           System.out.println(n);
       }
    //   System.out.println(shortestPath.size());
    //   System.out.println(shortestPath.get(0).nodeToString());
    //   System.out.println(shortestPath.get(shortestPath.size()).nodeToString());
       return s1;
    }

    
    /** 
     * Finds the shortest distance node on the list of unsettled nodes.
     * @param unsettled
     * @return Node
     */
    public Node getLowestDist(HashSet<Node> unsettled){
        Node lowestDistNode = null;
        int lowestDist = Integer.MAX_VALUE;
        for(Node node : unsettled){
            int nodeDist = node.getDistance();
            if(nodeDist < lowestDist){
                lowestDist = nodeDist;
                lowestDistNode = node;
            }
        }
        return lowestDistNode;
    }

    
    /** 
     * Calculates the distance between two nodes.
     * @param evalNode
     * @param edgeWeight
     * @param source
     * @return Node
     */
    public Node calculateMinDist(Node evalNode, int edgeWeight, Node source){
        int sourceDist = source.getDistance();
        if(sourceDist + edgeWeight < evalNode.getDistance()){
            evalNode.setDistance(sourceDist + edgeWeight);
            LinkedList<Node> shortestPath = new LinkedList<>(source.getShortestPath());
            shortestPath.add(source);
            evalNode.setShortestPath(shortestPath);
        }
        return evalNode;
    }

    
    /** 
     * Checks if a node is in the list of nodes.
     * @param nodeList
     * @param node1
     * @return boolean
     */
    public boolean inList(HashSet<Node> nodeList, Node node1){
        for(Node node2 : nodeList){
            if(node1.getX() == node2.getX() && node1.getY() == node2.getY()){
                return true;
            }
        }
        return false;
    }

}

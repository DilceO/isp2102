package frc.navigation;

public class Odometry {
    // start romi at (0,0) facing down the x axis as NORTH
    public int currDir = 0;
    public int currX = 0;
    public int currY = 0;


    public void turnedLeft(){
        currDir -= 1;
        while(currDir < 0){
            currDir += 4;
        }
        currDir %= 4;
    }
    public void turnedRight(){
        currDir += 1;
        currDir %= 4;
    }

    public void wentIntersection() {
            if (currDir == 0) {
                // NORTH
                currX += 1;
            }
            if (currDir == 1) {
                // EAST
                currY -= 1;
            }
            if (currDir == 2) {
                // SOUTH
                currX -= 1;
            }
            if (currDir == 3) {
                // WEST
                currY += 1;
        }
    }
}
